# SoundWave - Admin Portal, 4K Video & MP3 Audio Uploads with Duration Enforcement

A comprehensive upgrade adding a secure **Admin Panel** for authorized creators to upload both MP3 songs and 4K/HD videos with strict duration validation rules, paired with an integrated customer discovery feed and built-in video player.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following security and media specifications are confirmed:

- **Admin Authentication**:
  - Authorized Email: `admin@esports.com`
  - Authorized Password: `admin888$#@`
  - Secured session state: Admin panel is strictly locked behind credential verification with session logout.
- **Media Upload Specifications & Strict Limits**:
  - **MP3 Audio**: Maximum duration allowed is **30 minutes** (1,800,000 ms). Files longer than 30 minutes are blocked with an immediate validation warning.
  - **Video (4K / HD)**: Maximum duration allowed is **40 minutes** (2,400,000 ms). Files longer than 40 minutes are blocked with an immediate validation warning.
  - Automatic detection of video resolution (e.g. "4K Ultra HD", "1080p FHD", "720p HD") and duration via `MediaMetadataRetriever`.
- **Integrated Customer Feed**:
  - Customers see both audio tracks and music videos in a unified discovery feed with distinct visual badges (`4K Video`, `Audio`).
  - Seamless media switching: Tapping a video opens the high-definition video player; tapping an audio track triggers the background audio player.

---

## 1. Overview & Core Concept

### What It Does
1. **Admin Portal**: A secured management center requiring `admin@esports.com` and `admin888$#@`. Admins can upload MP3 audio tracks and 4K/HD music videos from device storage, manage all live tracks, view stream counts, and delete content.
2. **Duration Guardrails**: Automatically inspects file length before ingestion. Any audio > 30 mins or video > 40 mins is rejected with user-friendly error alerts.
3. **Integrated Player Engine**: Dual-engine playback supporting both native audio streaming and embedded full-featured video playback (play/pause, seek scrubber, aspect ratio handling, video timecode).

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌────────────────────────────────────────────────────────┐
│                   Top Bar Navigation                   │
│   [SoundWave ♫]          [Feed: All / Audio / Video]   │
│                          [Admin Portal 🔒]             │
└───────────────────────────┬────────────────────────────┘
                            │
            ┌───────────────┴───────────────┐
            ▼                               ▼
┌────────────────────────┐      ┌────────────────────────┐
│     CUSTOMER FEED      │      │     ADMIN PORTAL       │
│                        │      │                        │
│ • Unified Audio & Video│      │ • Login Challenge:     │
│ • "4K Video" Badges    │      │   admin@esports.com    │
│ • Audio: Plays in      │      │   admin888$#@          │
│   Mini & Full Player   │      │ • Upload Audio (≤30m)  │
│ • Video: Plays in      │      │ • Upload Video (≤40m)  │
│   Dedicated Video Modal│      │ • Duration Validation  │
│ • Filter: Audio / Video│      │ • Track Deletion & Stats│
└────────────────────────┘      └────────────────────────┘
```

### Visual Identity
- **Video Item Cards**: Sleek video preview cards with vibrant gradient backgrounds, play video icon, duration pill, and glowing cyan `4K Ultra HD` / `HD Video` chip.
- **Admin Modal / Portal**: High-tech cyber-security aesthetic with dark slate cards, lock indicators, password visibility toggle, upload drag-and-drop / file picker zones, and real-time validation bars.
- **Video Player Overlay**: Full-bleed modern video player with playback controls, timeline scrubber, elapsed and total duration, and minimize/close button.

---

## 3. Key Product Decisions & Trade-Offs

- **Database Model Extension**:
  - *Chosen Approach*: Add `mediaType` ("AUDIO" or "VIDEO"), `resolutionTag` ("4K", "1080p", "720p", "SD"), and `videoWidth`/`videoHeight` to `SongEntity`.
  - *Why*: Allows single unified queries while providing rich rendering distinctions and playback routing.
- **Duration Enforcement Location**:
  - *Chosen Approach*: Validated immediately in `AudioUploadHelper` and `AdminViewModel` upon file selection using `MediaMetadataRetriever` before writing the large file to disk.
  - *Why*: Prevents storage waste and provides instantaneous UI feedback to the admin if a file exceeds 30 or 40 minutes.
- **Integrated Video Player**:
  - *Chosen Approach*: Jetpack Compose `AndroidView` wrapping Android `VideoView` / `MediaPlayer` with custom styled Compose controls.
  - *Why*: Hardware accelerated, supports up to 4K local video decoding, and works reliably without heavy third-party bundle sizes.

---

## 4. Technical Architecture & Component Mapping

### Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│                             UI Layer                             │
│  MainActivity                                                    │
│    ├── HomeScreen (Unified Audio & Video Stream with filter)     │
│    ├── AdminLoginDialog (Authenticates admin@esports.com)        │
│    ├── AdminDashboardScreen (Upload Audio ≤30m, Video ≤40m, CRUD)│
│    ├── VideoPlayerModal (In-app 4K / HD Video Player overlay)    │
│    └── Mini & Full Audio Player (for audio tracks)               │
└─────────────────────────────────┬────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────┐
│                         ViewModel Layer                          │
│  MusicViewModel                                                  │
│    ├── adminState: isLoggedIn, loginError, activeAdminSession   │
│    ├── uploadState: isUploading, validationError                 │
│    ├── videoPlayerState: activeVideoSong, isPlayingVideo         │
│    └── filters: mediaTypeFilter (ALL / AUDIO / VIDEO)            │
└──────────────────┬───────────────────────────────┬───────────────┘
                   │                               │
                   ▼                               ▼
┌─────────────────────────────────────┐ ┌──────────────────────────┐
│            Media Engine             │ │     Room Data Layer      │
│  • AudioPlaybackManager (MP3)       │ │  • SongEntity (mediaType,│
│  • VideoPlaybackView (4K/HD Video)  │ │    resolutionTag, etc.)  │
│  • MediaValidationUtil (≤30m, ≤40m) │ │  • SongDao CRUD queries  │
└─────────────────────────────────────┘ └──────────────────────────┘
```

### Verification & Testing Plan
1. Test Admin Login with valid credentials (`admin@esports.com` & `admin888$#@`) and invalid credentials.
2. Verify audio upload duration validation rejects files > 30 minutes.
3. Verify video upload duration validation rejects files > 40 minutes.
4. Verify playback routing: audio tracks trigger the audio player, video tracks launch the video player modal.
5. Compile and run automated unit tests with `compile_applet`.
