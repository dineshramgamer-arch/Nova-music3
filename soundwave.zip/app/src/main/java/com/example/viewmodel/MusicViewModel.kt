package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AudioSeedUtil
import com.example.data.AudioUploadHelper
import com.example.data.MediaValidationUtil
import com.example.data.PlaylistEntity
import com.example.data.PlaylistSongCrossRef
import com.example.data.SongEntity
import com.example.playback.AudioPlaybackManager
import com.example.playback.PlaybackState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val songDao = database.songDao()
    private val playlistDao = database.playlistDao()

    private val audioPlaybackManager = AudioPlaybackManager(
        context = application,
        scope = viewModelScope,
        onSongPlayed = { songId ->
            viewModelScope.launch {
                songDao.incrementPlayCount(songId)
            }
        }
    )

    val playbackState: StateFlow<PlaybackState> = audioPlaybackManager.playbackState

    val allSongs: StateFlow<List<SongEntity>> = songDao.getAllSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteSongs: StateFlow<List<SongEntity>> = songDao.getFavoriteSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userUploads: StateFlow<List<SongEntity>> = songDao.getUserUploadedSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playlists: StateFlow<List<PlaylistEntity>> = playlistDao.getAllPlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin Authentication State
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    // Media Type filter: "ALL", "AUDIO", "VIDEO"
    private val _mediaTypeFilter = MutableStateFlow("ALL")
    val mediaTypeFilter: StateFlow<String> = _mediaTypeFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedGenre = MutableStateFlow("All")
    val selectedGenre: StateFlow<String> = _selectedGenre.asStateFlow()

    private val _isFullPlayerVisible = MutableStateFlow(false)
    val isFullPlayerVisible: StateFlow<Boolean> = _isFullPlayerVisible.asStateFlow()

    private val _activeVideoSong = MutableStateFlow<SongEntity?>(null)
    val activeVideoSong: StateFlow<SongEntity?> = _activeVideoSong.asStateFlow()

    private val _songToAddToPlaylist = MutableStateFlow<SongEntity?>(null)
    val songToAddToPlaylist: StateFlow<SongEntity?> = _songToAddToPlaylist.asStateFlow()

    private val _isUploading = MutableStateFlow(false)
    val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

    private val _uploadError = MutableStateFlow<String?>(null)
    val uploadError: StateFlow<String?> = _uploadError.asStateFlow()

    // Unified filtered songs for home discovery
    val filteredSongs: StateFlow<List<SongEntity>> = combine(
        allSongs,
        _searchQuery,
        _selectedGenre,
        _mediaTypeFilter
    ) { songs, query, genre, mediaType ->
        songs.filter { song ->
            val matchesQuery = query.isBlank() ||
                song.title.contains(query, ignoreCase = true) ||
                song.artist.contains(query, ignoreCase = true) ||
                song.genre.contains(query, ignoreCase = true)

            val matchesGenre = when (genre) {
                "All" -> true
                "Uploads" -> song.isUserUpload
                else -> song.genre.equals(genre, ignoreCase = true)
            }

            val matchesMediaType = when (mediaType) {
                "AUDIO" -> song.mediaType.equals("AUDIO", ignoreCase = true)
                "VIDEO" -> song.mediaType.equals("VIDEO", ignoreCase = true)
                else -> true
            }

            matchesQuery && matchesGenre && matchesMediaType
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            AudioSeedUtil.seedInitialSongsIfEmpty(getApplication(), database)
        }
    }

    fun loginAdmin(email: String, pass: String): Boolean {
        val success = MediaValidationUtil.validateCredentials(email, pass)
        _isAdminLoggedIn.value = success
        return success
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
    }

    fun playSongOrVideo(song: SongEntity, queue: List<SongEntity>? = null) {
        if (song.mediaType.equals("VIDEO", ignoreCase = true)) {
            // If audio was playing, pause it
            if (playbackState.value.isPlaying) {
                audioPlaybackManager.togglePlayPause()
            }
            _activeVideoSong.value = song
            viewModelScope.launch {
                songDao.incrementPlayCount(song.id)
            }
        } else {
            // Audio track
            _activeVideoSong.value = null
            val effectiveQueue = queue ?: filteredSongs.value.filter { it.mediaType.equals("AUDIO", ignoreCase = true) }
            audioPlaybackManager.playSong(song, effectiveQueue.ifEmpty { listOf(song) })
        }
    }

    fun dismissVideo() {
        _activeVideoSong.value = null
    }

    fun togglePlayPause() {
        audioPlaybackManager.togglePlayPause()
    }

    fun seekTo(positionMs: Long) {
        audioPlaybackManager.seekTo(positionMs)
    }

    fun skipNext() {
        audioPlaybackManager.skipNext()
    }

    fun skipPrevious() {
        audioPlaybackManager.skipPrevious()
    }

    fun toggleShuffle() {
        audioPlaybackManager.toggleShuffle()
    }

    fun toggleRepeat() {
        audioPlaybackManager.toggleRepeat()
    }

    fun toggleFavorite(songId: Long) {
        viewModelScope.launch {
            songDao.toggleFavorite(songId)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedGenre(genre: String) {
        _selectedGenre.value = genre
    }

    fun setMediaTypeFilter(filter: String) {
        _mediaTypeFilter.value = filter
    }

    fun setFullPlayerVisible(visible: Boolean) {
        _isFullPlayerVisible.value = visible
    }

    fun setSongToAddToPlaylist(song: SongEntity?) {
        _songToAddToPlaylist.value = song
    }

    fun uploadMedia(
        mediaUri: Uri,
        isAudio: Boolean,
        title: String,
        artist: String,
        genre: String,
        colorIndex: Int,
        onSuccess: (SongEntity) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isUploading.value = true
            _uploadError.value = null
            try {
                val song = AudioUploadHelper.saveUploadedMedia(
                    context = getApplication(),
                    mediaUri = mediaUri,
                    isAudio = isAudio,
                    customTitle = title,
                    customArtist = artist,
                    customGenre = genre,
                    colorIndex = colorIndex
                )
                val newId = songDao.insertSong(song)
                val savedSong = song.copy(id = newId)
                onSuccess(savedSong)
            } catch (e: IllegalArgumentException) {
                _uploadError.value = e.message
                onError(e.message ?: "Validation error")
            } catch (e: Exception) {
                val msg = "Upload failed: ${e.message}"
                _uploadError.value = msg
                onError(msg)
            } finally {
                _isUploading.value = false
            }
        }
    }

    fun deleteSong(song: SongEntity) {
        viewModelScope.launch {
            songDao.deleteSong(song)
            if (_activeVideoSong.value?.id == song.id) {
                _activeVideoSong.value = null
            }
        }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch {
            if (name.isNotBlank()) {
                playlistDao.insertPlaylist(PlaylistEntity(name = name.trim()))
            }
        }
    }

    fun deletePlaylist(playlist: PlaylistEntity) {
        viewModelScope.launch {
            playlistDao.deletePlaylist(playlist)
        }
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = songId))
            _songToAddToPlaylist.value = null
        }
    }

    fun getSongsForPlaylist(playlistId: Long) = playlistDao.getSongsForPlaylist(playlistId)

    override fun onCleared() {
        super.onCleared()
        audioPlaybackManager.release()
    }
}
