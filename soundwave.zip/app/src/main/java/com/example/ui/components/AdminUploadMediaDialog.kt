package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.CoverGradients
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.getCoverGradient

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminUploadMediaDialog(
    onDismiss: () -> Unit,
    onUploadConfirmed: (uri: Uri, isAudio: Boolean, title: String, artist: String, genre: String, colorIndex: Int) -> Unit,
    isUploading: Boolean
) {
    var isAudioMode by remember { mutableStateOf(true) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("Admin Official") }
    var selectedGenre by remember { mutableStateOf("Pop") }
    var selectedColorIndex by remember { mutableIntStateOf(0) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            errorMessage = null
            val rawName = uri.lastPathSegment?.substringAfterLast("/")?.substringBeforeLast(".")
            if (!rawName.isNullOrBlank() && title.isBlank()) {
                title = rawName.replace("_", " ").replace("-", " ").capitalize()
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            errorMessage = null
            val rawName = uri.lastPathSegment?.substringAfterLast("/")?.substringBeforeLast(".")
            if (!rawName.isNullOrBlank() && title.isBlank()) {
                title = rawName.replace("_", " ").replace("-", " ").capitalize()
            }
        }
    }

    val genres = listOf("Pop", "Lo-Fi", "Hip-Hop", "Synthwave", "Acoustic", "Bollywood", "4K Video", "Electronic")

    Dialog(
        onDismissRequest = { if (!isUploading) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(24.dp))
                .testTag("admin_upload_dialog"),
            color = DarkSurface,
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Admin Upload Portal",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = if (isAudioMode) "Audio Limit: Max 30 mins" else "Video Limit: Max 40 mins (up to 4K)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isAudioMode) ElectricViolet else NeonCyan
                        )
                    }
                    IconButton(onClick = onDismiss, enabled = !isUploading) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Toggle: Audio vs Video
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurfaceElevated)
                        .padding(4.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(enabled = !isUploading) {
                                if (!isAudioMode) {
                                    isAudioMode = true
                                    selectedUri = null
                                    errorMessage = null
                                }
                            },
                        color = if (isAudioMode) ElectricViolet else Color.Transparent,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Audiotrack, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "MP3 (≤30m)",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(enabled = !isUploading) {
                                if (isAudioMode) {
                                    isAudioMode = false
                                    selectedUri = null
                                    errorMessage = null
                                }
                            },
                        color = if (!isAudioMode) NeonCyan else Color.Transparent,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = if (!isAudioMode) Color.Black else Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "4K Video (≤40m)",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (!isAudioMode) Color.Black else Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // File Picker Zone
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = !isUploading) {
                            if (isAudioMode) audioPicker.launch("audio/*")
                            else videoPicker.launch("video/*")
                        }
                        .border(
                            width = 1.5.dp,
                            color = if (selectedUri != null) (if (isAudioMode) ElectricViolet else NeonCyan) else DarkSurfaceBorder,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .testTag("admin_pick_file_button"),
                    color = DarkSurfaceElevated,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(if (isAudioMode) ElectricViolet.copy(alpha = 0.2f) else NeonCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isAudioMode) Icons.Default.Audiotrack else Icons.Default.Movie,
                                contentDescription = null,
                                tint = if (isAudioMode) ElectricViolet else NeonCyan,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (selectedUri != null) {
                            Text(
                                text = if (isAudioMode) "Audio File Selected ✓" else "4K/HD Video File Selected ✓",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isAudioMode) ElectricViolet else NeonCyan
                            )
                            Text(
                                text = "Tap to choose a different file",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        } else {
                            Text(
                                text = if (isAudioMode) "Select MP3 Track (Max 30 min)" else "Select 4K Video (Max 40 min)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = TextPrimary
                            )
                            Text(
                                text = "Browse internal storage or documents",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title Input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(if (isAudioMode) "Song Title" else "Video Title") },
                    placeholder = { Text("e.g. Neon Horizon") },
                    modifier = Modifier.fillMaxWidth().testTag("admin_media_title_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricViolet,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    enabled = !isUploading
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Artist / Channel Name
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Artist / Channel Name") },
                    placeholder = { Text("e.g. Admin Official") },
                    modifier = Modifier.fillMaxWidth().testTag("admin_media_artist_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricViolet,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    enabled = !isUploading
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Genre Pills
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = "Category / Genre", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        genres.forEach { genre ->
                            val isSelected = selectedGenre == genre
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable(enabled = !isUploading) { selectedGenre = genre },
                                color = if (isSelected) ElectricViolet else DarkSurfaceElevated,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = genre,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (isSelected) Color.White else TextSecondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Album Art Gradient Selector
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = "Cover Artwork Theme", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CoverGradients.indices.forEach { index ->
                            val isSelected = selectedColorIndex == index
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(getCoverGradient(index))
                                    .clickable(enabled = !isUploading) { selectedColorIndex = index }
                                    .border(
                                        width = if (isSelected) 2.5.dp else 0.dp,
                                        color = if (isSelected) Color.White else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFEF4444)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Publish Button
                Button(
                    onClick = {
                        val uri = selectedUri
                        if (uri == null) {
                            errorMessage = if (isAudioMode) "Please select an MP3 audio file first" else "Please select a video file first"
                            return@Button
                        }
                        if (title.isBlank()) {
                            errorMessage = "Please enter a title"
                            return@Button
                        }
                        onUploadConfirmed(
                            uri,
                            isAudioMode,
                            title.trim(),
                            artist.trim().ifEmpty { "Admin Official" },
                            selectedGenre,
                            selectedColorIndex
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("admin_publish_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isAudioMode) ElectricViolet else NeonCyan),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isUploading
                ) {
                    if (isUploading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Validating & Processing...", color = Color.White)
                    } else {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, tint = if (isAudioMode) Color.White else Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isAudioMode) "Publish MP3 Track" else "Publish 4K Video",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isAudioMode) Color.White else Color.Black
                        )
                    }
                }
            }
        }
    }
}
