package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Primary Studio Dark Colors
val DarkBackground = Color(0xFF0A0C14)
val DarkSurface = Color(0xFF131725)
val DarkSurfaceElevated = Color(0xFF1D2236)
val DarkSurfaceBorder = Color(0xFF2B324D)

// Brand Accents
val ElectricViolet = Color(0xFFA855F7)
val NeonPink = Color(0xFFEC4899)
val NeonCyan = Color(0xFF06B6D4)
val ElectricBlue = Color(0xFF3B82F6)
val EmeraldGreen = Color(0xFF10B981)
val WarmAmber = Color(0xFFF59E0B)

// Text & Neutral Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Cover Art Gradient presets for songs
val CoverGradients = listOf(
    listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)),
    listOf(Color(0xFF06B6D4), Color(0xFF3B82F6)),
    listOf(Color(0xFFF59E0B), Color(0xFFEF4444)),
    listOf(Color(0xFF10B981), Color(0xFF06B6D4)),
    listOf(Color(0xFF6366F1), Color(0xFFA855F7)),
    listOf(Color(0xFFF43F5E), Color(0xFFFB923C))
)

fun getCoverGradient(index: Int): Brush {
    val colors = CoverGradients[index.coerceIn(0, CoverGradients.lastIndex)]
    return Brush.linearGradient(colors)
}
