package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.SongEntity
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.AdminLoginDialog
import com.example.ui.components.AdminUploadMediaDialog
import com.example.ui.components.FullPlayerModal
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.VideoPlayerModal
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.SoundWaveTheme
import com.example.ui.theme.TextMuted
import com.example.viewmodel.MusicViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SoundWaveTheme {
                SoundWaveApp()
            }
        }
    }
}

@Composable
fun SoundWaveApp(
    viewModel: MusicViewModel = viewModel()
) {
    val context = LocalContext.current
    var currentTab by remember { mutableIntStateOf(0) }
    var showLoginDialog by remember { mutableStateOf(false) }
    var showAdminUploadDialog by remember { mutableStateOf(false) }

    val filteredSongs by viewModel.filteredSongs.collectAsStateWithLifecycle()
    val allSongs by viewModel.allSongs.collectAsStateWithLifecycle()
    val userUploads by viewModel.userUploads.collectAsStateWithLifecycle()
    val favoriteSongs by viewModel.favoriteSongs.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedGenre by viewModel.selectedGenre.collectAsStateWithLifecycle()
    val mediaTypeFilter by viewModel.mediaTypeFilter.collectAsStateWithLifecycle()
    val isFullPlayerVisible by viewModel.isFullPlayerVisible.collectAsStateWithLifecycle()
    val activeVideoSong by viewModel.activeVideoSong.collectAsStateWithLifecycle()
    val songToAddToPlaylist by viewModel.songToAddToPlaylist.collectAsStateWithLifecycle()
    val isUploading by viewModel.isUploading.collectAsStateWithLifecycle()
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsStateWithLifecycle()

    // Back button handling
    BackHandler(
        enabled = activeVideoSong != null ||
            isFullPlayerVisible ||
            showAdminUploadDialog ||
            showLoginDialog ||
            songToAddToPlaylist != null ||
            currentTab != 0
    ) {
        when {
            activeVideoSong != null -> viewModel.dismissVideo()
            isFullPlayerVisible -> viewModel.setFullPlayerVisible(false)
            showAdminUploadDialog -> showAdminUploadDialog = false
            showLoginDialog -> showLoginDialog = false
            songToAddToPlaylist != null -> viewModel.setSongToAddToPlaylist(null)
            currentTab != 0 -> currentTab = 0
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        containerColor = DarkBackground,
        bottomBar = {
            Column(
                modifier = Modifier
                    .background(DarkBackground)
                    .navigationBarsPadding()
            ) {
                // Docked Mini Player (only when not playing a full-screen video)
                if (activeVideoSong == null) {
                    MiniPlayerBar(
                        playbackState = playbackState,
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSkipNext = { viewModel.skipNext() },
                        onExpandClick = { viewModel.setFullPlayerVisible(true) }
                    )
                }

                // Bottom Navigation Bar
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 4.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == 0) Icons.Default.Explore else Icons.Outlined.Explore,
                                contentDescription = "Discover"
                            )
                        },
                        label = {
                            Text(
                                text = "Discover",
                                fontWeight = if (currentTab == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ElectricViolet,
                            selectedTextColor = ElectricViolet,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.testTag("nav_item_discover")
                    )

                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = {
                            if (isAdminLoggedIn) {
                                currentTab = 1
                            } else {
                                showLoginDialog = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == 1) Icons.Default.AdminPanelSettings else Icons.Outlined.AdminPanelSettings,
                                contentDescription = "Admin Portal"
                            )
                        },
                        label = {
                            Text(
                                text = if (isAdminLoggedIn) "Admin" else "Admin Login",
                                fontWeight = if (currentTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ElectricViolet,
                            selectedTextColor = ElectricViolet,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.testTag("nav_item_admin")
                    )

                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == 2) Icons.Default.LibraryMusic else Icons.Outlined.LibraryMusic,
                                contentDescription = "Library"
                            )
                        },
                        label = {
                            Text(
                                text = "Library",
                                fontWeight = if (currentTab == 2) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ElectricViolet,
                            selectedTextColor = ElectricViolet,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.testTag("nav_item_library")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> HomeScreen(
                    songs = filteredSongs,
                    userUploads = userUploads,
                    playbackState = playbackState,
                    searchQuery = searchQuery,
                    selectedGenre = selectedGenre,
                    mediaTypeFilter = mediaTypeFilter,
                    isAdminLoggedIn = isAdminLoggedIn,
                    onSearchChange = { viewModel.setSearchQuery(it) },
                    onGenreSelect = { viewModel.setSelectedGenre(it) },
                    onMediaTypeSelect = { viewModel.setMediaTypeFilter(it) },
                    onSongClick = { viewModel.playSongOrVideo(it) },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    onAddToPlaylist = { viewModel.setSongToAddToPlaylist(it) },
                    onOpenAdminPortal = {
                        if (isAdminLoggedIn) {
                            currentTab = 1
                        } else {
                            showLoginDialog = true
                        }
                    }
                )

                1 -> AdminDashboardScreen(
                    allMedia = allSongs,
                    playbackState = playbackState,
                    onUploadClick = { showAdminUploadDialog = true },
                    onMediaClick = { viewModel.playSongOrVideo(it) },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    onAddToPlaylist = { viewModel.setSongToAddToPlaylist(it) },
                    onDeleteMedia = { viewModel.deleteSong(it) },
                    onLogout = {
                        viewModel.logoutAdmin()
                        currentTab = 0
                        Toast.makeText(context, "Logged out of Admin Portal", Toast.LENGTH_SHORT).show()
                    }
                )

                2 -> LibraryScreen(
                    favoriteSongs = favoriteSongs,
                    playlists = playlists,
                    playbackState = playbackState,
                    onSongClick = { song, _ -> viewModel.playSongOrVideo(song) },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    onAddToPlaylist = { viewModel.setSongToAddToPlaylist(it) },
                    onCreatePlaylist = { viewModel.createPlaylist(it) },
                    onDeletePlaylist = { viewModel.deletePlaylist(it) },
                    getPlaylistSongs = { viewModel.getSongsForPlaylist(it) }
                )
            }
        }
    }

    // Video Player Modal (for 4K and HD videos)
    activeVideoSong?.let { videoSong ->
        VideoPlayerModal(
            videoSong = videoSong,
            onDismiss = { viewModel.dismissVideo() }
        )
    }

    // Full Screen Audio Player Modal (for audio tracks)
    if (isFullPlayerVisible && playbackState.currentSong != null && activeVideoSong == null) {
        FullPlayerModal(
            playbackState = playbackState,
            onDismiss = { viewModel.setFullPlayerVisible(false) },
            onTogglePlayPause = { viewModel.togglePlayPause() },
            onSeekTo = { viewModel.seekTo(it) },
            onSkipNext = { viewModel.skipNext() },
            onSkipPrevious = { viewModel.skipPrevious() },
            onToggleShuffle = { viewModel.toggleShuffle() },
            onToggleRepeat = { viewModel.toggleRepeat() },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            onAddToPlaylist = {
                val song = playbackState.currentSong
                if (song != null) {
                    viewModel.setSongToAddToPlaylist(song)
                }
            }
        )
    }

    // Admin Login Dialog
    if (showLoginDialog) {
        AdminLoginDialog(
            onDismiss = { showLoginDialog = false },
            onLoginSuccess = {
                viewModel.loginAdmin("admin@esports.com", "admin888$#@")
                showLoginDialog = false
                currentTab = 1
                Toast.makeText(context, "Admin verified! Welcome admin@esports.com", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Admin Upload Media Dialog
    if (showAdminUploadDialog) {
        AdminUploadMediaDialog(
            onDismiss = { showAdminUploadDialog = false },
            onUploadConfirmed = { uri, isAudio, title, artist, genre, colorIndex ->
                viewModel.uploadMedia(
                    mediaUri = uri,
                    isAudio = isAudio,
                    title = title,
                    artist = artist,
                    genre = genre,
                    colorIndex = colorIndex,
                    onSuccess = { createdSong ->
                        showAdminUploadDialog = false
                        val typeStr = if (createdSong.mediaType == "AUDIO") "MP3 track" else "4K video"
                        Toast.makeText(context, "Published $typeStr: ${createdSong.title} successfully!", Toast.LENGTH_LONG).show()
                    },
                    onError = { error ->
                        Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                    }
                )
            },
            isUploading = isUploading
        )
    }

    // Add to Playlist Dialog
    songToAddToPlaylist?.let { song ->
        AddToPlaylistDialog(
            song = song,
            playlists = playlists,
            onDismiss = { viewModel.setSongToAddToPlaylist(null) },
            onPlaylistSelected = { playlistId ->
                viewModel.addSongToPlaylist(playlistId, song.id)
            },
            onCreatePlaylist = { name ->
                viewModel.createPlaylist(name)
            }
        )
    }
}
