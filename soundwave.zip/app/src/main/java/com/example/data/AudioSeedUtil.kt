package com.example.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

object AudioSeedUtil {

    suspend fun seedInitialSongsIfEmpty(context: Context, database: AppDatabase) = withContext(Dispatchers.IO) {
        val songDao = database.songDao()
        if (songDao.getSongCount() > 0) return@withContext

        val musicDir = File(context.filesDir, "seed_tracks").apply { mkdirs() }

        val track1 = createLofiTrack(File(musicDir, "midnight_lofi.wav"))
        val track2 = createSynthwaveTrack(File(musicDir, "neon_skyline.wav"))
        val track3 = createAcousticTrack(File(musicDir, "monsoon_serenade.wav"))
        val track4 = createGrooveTrack(File(musicDir, "urban_groove.wav"))

        val initialSongs = listOf(
            SongEntity(
                title = "Midnight Lo-Fi Chill",
                artist = "Luna Wave",
                genre = "Lo-Fi",
                durationMs = track1.second,
                filePath = track1.first,
                isUserUpload = false,
                isFavorite = true,
                playCount = 142,
                gradientColorIndex = 0,
                mediaType = "AUDIO",
                resolutionTag = ""
            ),
            SongEntity(
                title = "Cyber Neon Journey",
                artist = "Cyberpulse",
                genre = "Synthwave",
                durationMs = track2.second,
                filePath = track2.first,
                isUserUpload = false,
                isFavorite = false,
                playCount = 198,
                gradientColorIndex = 1,
                mediaType = "VIDEO",
                resolutionTag = "4K Ultra HD",
                videoWidth = 3840,
                videoHeight = 2160
            ),
            SongEntity(
                title = "Monsoon Serenade",
                artist = "Aarav Studio",
                genre = "Acoustic",
                durationMs = track3.second,
                filePath = track3.first,
                isUserUpload = false,
                isFavorite = true,
                playCount = 230,
                gradientColorIndex = 2,
                mediaType = "AUDIO",
                resolutionTag = ""
            ),
            SongEntity(
                title = "Urban Groove Music Video",
                artist = "Beatsmith",
                genre = "Hip-Hop",
                durationMs = track4.second,
                filePath = track4.first,
                isUserUpload = false,
                isFavorite = false,
                playCount = 176,
                gradientColorIndex = 3,
                mediaType = "VIDEO",
                resolutionTag = "1080p FHD",
                videoWidth = 1920,
                videoHeight = 1080
            )
        )

        songDao.insertAll(initialSongs)

        val playlistDao = database.playlistDao()
        val chillPlaylistId = playlistDao.insertPlaylist(
            PlaylistEntity(name = "Late Night Chill")
        )
        val allSongs = songDao.getSongById(1)
        if (allSongs != null) {
            playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = chillPlaylistId, songId = 1))
            playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = chillPlaylistId, songId = 2))
        }
    }

    private fun createLofiTrack(outputFile: File): Pair<String, Long> {
        val sampleRate = 22050
        val durationSeconds = 24.0
        val totalSamples = (sampleRate * durationSeconds).toInt()
        val samples = ShortArray(totalSamples)

        val chordProgressions = listOf(
            listOf(293.66, 349.23, 440.0, 523.25),
            listOf(196.00, 246.94, 293.66, 349.23),
            listOf(261.63, 329.63, 392.00, 493.88),
            listOf(220.00, 261.63, 329.63, 392.00)
        )

        val chordDuration = 6.0
        val chordSamples = (sampleRate * chordDuration).toInt()

        for (i in 0 until totalSamples) {
            val chordIndex = ((i / chordSamples) % chordProgressions.size)
            val currentChord = chordProgressions[chordIndex]
            val chordSamplePos = i % chordSamples
            val chordTime = chordSamplePos.toDouble() / sampleRate

            val env = when {
                chordTime < 0.2 -> (chordTime / 0.2)
                chordTime > 5.5 -> (6.0 - chordTime) / 0.5
                else -> 1.0 - (chordTime / 12.0)
            }

            var sum = 0.0
            for (freq in currentChord) {
                val tone = sin(2.0 * PI * freq * (i.toDouble() / sampleRate))
                val subTone = 0.5 * sin(2.0 * PI * (freq * 0.5) * (i.toDouble() / sampleRate))
                val mellowHarmonic = 0.25 * sin(2.0 * PI * (freq * 2.0) * (i.toDouble() / sampleRate))
                sum += (tone + subTone + mellowHarmonic)
            }

            val tremolo = 1.0 + 0.1 * sin(2.0 * PI * 3.5 * (i.toDouble() / sampleRate))
            val value = (sum * 0.22 * env * tremolo * 32767.0).coerceIn(-32768.0, 32767.0)
            samples[i] = value.toInt().toShort()
        }

        writeWavFile(outputFile, samples, sampleRate)
        return Pair(outputFile.absolutePath, (durationSeconds * 1000).toLong())
    }

    private fun createSynthwaveTrack(outputFile: File): Pair<String, Long> {
        val sampleRate = 22050
        val durationSeconds = 20.0
        val totalSamples = (sampleRate * durationSeconds).toInt()
        val samples = ShortArray(totalSamples)

        val bassNotes = listOf(174.61, 196.00, 220.00, 164.81)
        val arpNotes = listOf(349.23, 440.00, 523.25, 659.25)

        val barDuration = 5.0
        val barSamples = (sampleRate * barDuration).toInt()
        val arpSpeed = 0.25

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val barIndex = ((i / barSamples) % bassNotes.size)
            val bassFreq = bassNotes[barIndex]

            val bassPulse = sin(2.0 * PI * bassFreq * t) + 0.6 * sin(2.0 * PI * (bassFreq * 2) * t)
            val noteStep = ((t / arpSpeed).toInt() % arpNotes.size)
            val arpFreq = arpNotes[noteStep]
            val arpTone = sin(2.0 * PI * arpFreq * t)
            val beatEnv = 1.0 - ((t % 0.5) / 0.5)

            val combined = (bassPulse * 0.45 + arpTone * 0.35 + beatEnv * 0.2) * 32767.0
            samples[i] = combined.coerceIn(-32768.0, 32767.0).toInt().toShort()
        }

        writeWavFile(outputFile, samples, sampleRate)
        return Pair(outputFile.absolutePath, (durationSeconds * 1000).toLong())
    }

    private fun createAcousticTrack(outputFile: File): Pair<String, Long> {
        val sampleRate = 22050
        val durationSeconds = 24.0
        val totalSamples = (sampleRate * durationSeconds).toInt()
        val samples = ShortArray(totalSamples)

        val chords = listOf(
            listOf(164.81, 196.00, 246.94, 329.63),
            listOf(146.83, 220.00, 293.66, 369.99),
            listOf(130.81, 196.00, 261.63, 329.63),
            listOf(123.47, 185.00, 246.94, 311.13)
        )

        val chordDuration = 6.0
        val chordSamples = (sampleRate * chordDuration).toInt()

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val chordIndex = ((i / chordSamples) % chords.size)
            val currentChord = chords[chordIndex]

            var sum = 0.0
            for ((idx, freq) in currentChord.withIndex()) {
                val strumOffset = idx * 0.04
                val strumTime = (t % 1.5) - strumOffset
                val strumEnv = if (strumTime > 0.0) {
                    Math.exp(-strumTime * 3.5)
                } else 0.0

                sum += sin(2.0 * PI * freq * t) * strumEnv
            }

            val value = (sum * 0.35 * 32767.0).coerceIn(-32768.0, 32767.0)
            samples[i] = value.toInt().toShort()
        }

        writeWavFile(outputFile, samples, sampleRate)
        return Pair(outputFile.absolutePath, (durationSeconds * 1000).toLong())
    }

    private fun createGrooveTrack(outputFile: File): Pair<String, Long> {
        val sampleRate = 22050
        val durationSeconds = 18.0
        val totalSamples = (sampleRate * durationSeconds).toInt()
        val samples = ShortArray(totalSamples)

        val bassFreqs = listOf(110.0, 130.81, 146.83, 164.81)

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val section = ((t / 4.5).toInt() % bassFreqs.size)
            val bass = bassFreqs[section]

            val bassTone = sin(2.0 * PI * bass * t) + 0.4 * sin(2.0 * PI * (bass * 3) * t)
            val melodyFreq = bass * 2.5
            val melodyTone = sin(2.0 * PI * melodyFreq * t)
            val hat = if ((t % 0.5) < 0.05) ((Math.random() * 2.0 - 1.0) * 0.3) else 0.0

            val combined = (bassTone * 0.4 + melodyTone * 0.3 + hat) * 32767.0
            samples[i] = combined.coerceIn(-32768.0, 32767.0).toInt().toShort()
        }

        writeWavFile(outputFile, samples, sampleRate)
        return Pair(outputFile.absolutePath, (durationSeconds * 1000).toLong())
    }

    private fun writeWavFile(file: File, samples: ShortArray, sampleRate: Int) {
        val numChannels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * numChannels * bitsPerSample / 8
        val blockAlign = numChannels * bitsPerSample / 8
        val dataSize = samples.size * 2
        val chunkSize = 36 + dataSize

        FileOutputStream(file).use { fos ->
            val header = ByteBuffer.allocate(44).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                put("RIFF".toByteArray())
                putInt(chunkSize)
                put("WAVE".toByteArray())
                put("fmt ".toByteArray())
                putInt(16)
                putShort(1)
                putShort(numChannels.toShort())
                putInt(sampleRate)
                putInt(byteRate)
                putShort(blockAlign.toShort())
                putShort(bitsPerSample.toShort())
                put("data".toByteArray())
                putInt(dataSize)
            }
            fos.write(header.array())

            val sampleBuffer = ByteBuffer.allocate(samples.size * 2).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                for (s in samples) {
                    putShort(s)
                }
            }
            fos.write(sampleBuffer.array())
        }
    }
}
