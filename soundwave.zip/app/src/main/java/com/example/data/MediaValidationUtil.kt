package com.example.data

object MediaValidationUtil {
    const val ADMIN_EMAIL = "admin@esports.com"
    const val ADMIN_PASSWORD = "admin888$#@"

    const val AUDIO_MAX_DURATION_MS: Long = 30 * 60 * 1000L // 30 minutes
    const val VIDEO_MAX_DURATION_MS: Long = 40 * 60 * 1000L // 40 minutes

    fun validateCredentials(email: String, pass: String): Boolean {
        return email.trim().equals(ADMIN_EMAIL, ignoreCase = true) && pass == ADMIN_PASSWORD
    }

    fun validateAudioDuration(durationMs: Long): String? {
        if (durationMs > AUDIO_MAX_DURATION_MS) {
            val minutes = durationMs / 60000
            return "Audio duration (${minutes}m) exceeds the allowed limit of 30 minutes!"
        }
        return null
    }

    fun validateVideoDuration(durationMs: Long): String? {
        if (durationMs > VIDEO_MAX_DURATION_MS) {
            val minutes = durationMs / 60000
            return "Video duration (${minutes}m) exceeds the allowed limit of 40 minutes!"
        }
        return null
    }

    fun determineResolutionTag(width: Int, height: Int): String {
        val maxDim = maxOf(width, height)
        val minDim = minOf(width, height)

        return when {
            maxDim >= 3840 || minDim >= 2160 -> "4K Ultra HD"
            maxDim >= 1920 || minDim >= 1080 -> "1080p FHD"
            maxDim >= 1280 || minDim >= 720 -> "720p HD"
            width > 0 && height > 0 -> "SD Video"
            else -> "4K Video"
        }
    }
}
