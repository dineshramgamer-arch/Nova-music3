package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val artist: String,
    val genre: String, // "Lo-Fi", "Pop", "Synthwave", "Acoustic", "Hip-Hop", "Custom"
    val durationMs: Long,
    val filePath: String,
    val isUserUpload: Boolean = false,
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val gradientColorIndex: Int = 0,
    val mediaType: String = "AUDIO", // "AUDIO" or "VIDEO"
    val resolutionTag: String = "",  // "4K", "1080p", "HD"
    val videoWidth: Int = 0,
    val videoHeight: Int = 0
)
