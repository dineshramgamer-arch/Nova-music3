package com.example.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object AudioUploadHelper {

    suspend fun saveUploadedMedia(
        context: Context,
        mediaUri: Uri,
        isAudio: Boolean,
        customTitle: String? = null,
        customArtist: String? = null,
        customGenre: String? = null,
        colorIndex: Int = 0
    ): SongEntity = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        val uploadsDir = File(context.filesDir, if (isAudio) "uploaded_songs" else "uploaded_videos").apply { mkdirs() }

        // Extract original file name
        var originalFileName = if (isAudio) "audio_${System.currentTimeMillis()}.mp3" else "video_${System.currentTimeMillis()}.mp4"
        contentResolver.query(mediaUri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex != -1 && cursor.moveToFirst()) {
                val name = cursor.getString(nameIndex)
                if (!name.isNullOrBlank()) {
                    originalFileName = name
                }
            }
        }

        // Target file in app internal storage
        val safeName = originalFileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val destFile = File(uploadsDir, "${System.currentTimeMillis()}_$safeName")

        // Copy stream
        contentResolver.openInputStream(mediaUri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }

        // Read metadata using MediaMetadataRetriever
        var extractedTitle: String? = null
        var extractedArtist: String? = null
        var extractedGenre: String? = null
        var durationMs: Long = 0
        var videoWidth = 0
        var videoHeight = 0

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(destFile.absolutePath)
            extractedTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            extractedArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            extractedGenre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            if (!durationStr.isNullOrBlank()) {
                durationMs = durationStr.toLongOrNull() ?: 0L
            }
            if (!isAudio) {
                val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                videoWidth = widthStr?.toIntOrNull() ?: 0
                videoHeight = heightStr?.toIntOrNull() ?: 0
            }
        } catch (_: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        // Strict Duration Enforcement
        if (isAudio) {
            val audioError = MediaValidationUtil.validateAudioDuration(durationMs)
            if (audioError != null) {
                destFile.delete() // Cleanup invalid file
                throw IllegalArgumentException(audioError)
            }
        } else {
            val videoError = MediaValidationUtil.validateVideoDuration(durationMs)
            if (videoError != null) {
                destFile.delete() // Cleanup invalid file
                throw IllegalArgumentException(videoError)
            }
        }

        if (durationMs <= 0L) {
            durationMs = if (isAudio) 180000L else 240000L
        }

        val finalTitle = if (!customTitle.isNullOrBlank()) customTitle
        else if (!extractedTitle.isNullOrBlank()) extractedTitle
        else originalFileName.substringBeforeLast(".")

        val finalArtist = if (!customArtist.isNullOrBlank()) customArtist
        else if (!extractedArtist.isNullOrBlank()) extractedArtist
        else "Admin Upload"

        val finalGenre = if (!customGenre.isNullOrBlank()) customGenre
        else if (!extractedGenre.isNullOrBlank()) extractedGenre
        else if (isAudio) "Music" else "4K Video"

        val resolutionTag = if (!isAudio) {
            MediaValidationUtil.determineResolutionTag(videoWidth, videoHeight)
        } else ""

        SongEntity(
            title = finalTitle,
            artist = finalArtist,
            genre = finalGenre,
            durationMs = durationMs,
            filePath = destFile.absolutePath,
            isUserUpload = true,
            isFavorite = false,
            playCount = 0,
            createdAt = System.currentTimeMillis(),
            gradientColorIndex = colorIndex % 6,
            mediaType = if (isAudio) "AUDIO" else "VIDEO",
            resolutionTag = resolutionTag,
            videoWidth = videoWidth,
            videoHeight = videoHeight
        )
    }
}
