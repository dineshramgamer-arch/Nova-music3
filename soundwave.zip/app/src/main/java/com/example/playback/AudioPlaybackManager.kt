package com.example.playback

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.example.data.SongEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class PlaybackState(
    val currentSong: SongEntity? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isShuffle: Boolean = false,
    val isRepeat: Boolean = false,
    val queue: List<SongEntity> = emptyList(),
    val queueIndex: Int = -1
)

class AudioPlaybackManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onSongPlayed: (Long) -> Unit
) {
    private var mediaPlayer: MediaPlayer? = null
    private var tickerJob: Job? = null

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private fun getOrCreatePlayer(): MediaPlayer {
        return mediaPlayer ?: MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setOnCompletionListener {
                handleSongCompletion()
            }
            setOnErrorListener { _, what, extra ->
                _playbackState.value = _playbackState.value.copy(isPlaying = false)
                stopTicker()
                true
            }
            mediaPlayer = this
        }
    }

    fun playSong(song: SongEntity, newQueue: List<SongEntity>? = null) {
        val player = getOrCreatePlayer()
        try {
            player.reset()

            val file = File(song.filePath)
            if (file.exists()) {
                player.setDataSource(file.absolutePath)
            } else {
                return
            }

            player.prepare()
            player.start()

            val queue = newQueue ?: _playbackState.value.queue
            val queueIdx = queue.indexOfFirst { it.id == song.id }.let { if (it == -1) 0 else it }
            val realDuration = player.duration.toLong().let { if (it > 0) it else song.durationMs }

            _playbackState.value = _playbackState.value.copy(
                currentSong = song,
                isPlaying = true,
                currentPositionMs = 0L,
                durationMs = realDuration,
                queue = queue,
                queueIndex = queueIdx
            )

            startTicker()
            onSongPlayed(song.id)
        } catch (e: Exception) {
            e.printStackTrace()
            _playbackState.value = _playbackState.value.copy(isPlaying = false)
            stopTicker()
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: return
        val currentSong = _playbackState.value.currentSong ?: return

        if (player.isPlaying) {
            player.pause()
            _playbackState.value = _playbackState.value.copy(isPlaying = false)
            stopTicker()
        } else {
            try {
                player.start()
                _playbackState.value = _playbackState.value.copy(isPlaying = true)
                startTicker()
            } catch (e: Exception) {
                // If media player was released/error state, re-play
                playSong(currentSong)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        val player = mediaPlayer ?: return
        val bounded = positionMs.coerceIn(0L, _playbackState.value.durationMs)
        player.seekTo(bounded.toInt())
        _playbackState.value = _playbackState.value.copy(currentPositionMs = bounded)
    }

    fun skipNext() {
        val state = _playbackState.value
        val queue = state.queue
        if (queue.isEmpty()) return

        val nextIndex = if (state.isShuffle) {
            queue.indices.filter { it != state.queueIndex }.randomOrNull() ?: 0
        } else {
            (state.queueIndex + 1) % queue.size
        }

        playSong(queue[nextIndex])
    }

    fun skipPrevious() {
        val state = _playbackState.value
        val queue = state.queue
        if (queue.isEmpty()) return

        // If played more than 3 seconds, restart current track
        if (state.currentPositionMs > 3000L) {
            seekTo(0L)
            return
        }

        val prevIndex = if (state.queueIndex - 1 < 0) queue.lastIndex else state.queueIndex - 1
        playSong(queue[prevIndex])
    }

    fun toggleShuffle() {
        _playbackState.value = _playbackState.value.copy(
            isShuffle = !_playbackState.value.isShuffle
        )
    }

    fun toggleRepeat() {
        _playbackState.value = _playbackState.value.copy(
            isRepeat = !_playbackState.value.isRepeat
        )
    }

    private fun handleSongCompletion() {
        val state = _playbackState.value
        if (state.isRepeat && state.currentSong != null) {
            seekTo(0L)
            mediaPlayer?.start()
            _playbackState.value = _playbackState.value.copy(isPlaying = true)
            startTicker()
        } else {
            skipNext()
        }
    }

    private fun startTicker() {
        stopTicker()
        tickerJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                val player = mediaPlayer
                if (player != null && player.isPlaying) {
                    val pos = player.currentPosition.toLong()
                    val dur = player.duration.toLong().let { if (it > 0) it else _playbackState.value.durationMs }
                    _playbackState.value = _playbackState.value.copy(
                        currentPositionMs = pos,
                        durationMs = dur
                    )
                }
                delay(200L)
            }
        }
    }

    private fun stopTicker() {
        tickerJob?.cancel()
        tickerJob = null
    }

    fun release() {
        stopTicker()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
