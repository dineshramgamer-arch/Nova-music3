package com.example

import com.example.data.MediaValidationUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testAdminCredentialsValidation() {
        assertTrue(MediaValidationUtil.validateCredentials("admin@esports.com", "admin888$#@"))
        assertTrue(MediaValidationUtil.validateCredentials("ADMIN@ESPORTS.COM", "admin888$#@"))
        assertFalse(MediaValidationUtil.validateCredentials("admin@esports.com", "wrongpassword"))
        assertFalse(MediaValidationUtil.validateCredentials("user@esports.com", "admin888$#@"))
    }

    @Test
    fun testAudioDurationLimitThirtyMinutes() {
        // Under 30 minutes (e.g. 25 minutes = 1500000 ms) should pass
        assertNull(MediaValidationUtil.validateAudioDuration(25 * 60 * 1000L))
        // Exactly 30 minutes should pass
        assertNull(MediaValidationUtil.validateAudioDuration(30 * 60 * 1000L))
        // Over 30 minutes (e.g. 31 minutes = 1860000 ms) should be rejected
        assertNotNull(MediaValidationUtil.validateAudioDuration(31 * 60 * 1000L))
    }

    @Test
    fun testVideoDurationLimitFortyMinutes() {
        // Under 40 minutes (e.g. 35 minutes) should pass
        assertNull(MediaValidationUtil.validateVideoDuration(35 * 60 * 1000L))
        // Exactly 40 minutes should pass
        assertNull(MediaValidationUtil.validateVideoDuration(40 * 60 * 1000L))
        // Over 40 minutes (e.g. 42 minutes) should be rejected
        assertNotNull(MediaValidationUtil.validateVideoDuration(42 * 60 * 1000L))
    }

    @Test
    fun testResolutionTagDetection() {
        assertEquals("4K Ultra HD", MediaValidationUtil.determineResolutionTag(3840, 2160))
        assertEquals("1080p FHD", MediaValidationUtil.determineResolutionTag(1920, 1080))
        assertEquals("720p HD", MediaValidationUtil.determineResolutionTag(1280, 720))
    }
}
